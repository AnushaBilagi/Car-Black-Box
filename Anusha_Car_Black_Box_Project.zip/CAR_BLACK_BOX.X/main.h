#ifndef MAIN_H
#define	MAIN_H

void init_config(void);
void int_to_str(unsigned int num, char *str);
void display_menu();
void collision();
void save_log(unsigned char speed, unsigned char gear);
void clear_log();
void download_log();
void set_log();

//clcd
#define CLCD_PORT			PORTD
#define CLCD_EN				RC2
#define CLCD_RS				RC1
#define CLCD_RW				RC0
#define CLCD_BUSY			RD7
#define PORT_DIR			TRISD7


#define HI												1
#define LO												0

#define INPUT											0xFF
#define OUTPUT											0x00

#define DATA_COMMAND									1
#define INSTRUCTION_COMMAND								0
#define _XTAL_FREQ                  20000000
#define LINE1(x)									(0x80 + (x))
#define LINE2(x)										(0xC0 + (x))

#define TWO_LINE_5x8_MATRIX_8_BIT					clcd_write(0x38, INSTRUCTION_COMMAND)
#define CLEAR_DISP_SCREEN				                clcd_write(0x01, INSTRUCTION_COMMAND)
#define CURSOR_HOME							clcd_write(0x02, INSTRUCTION_COMMAND)
#define DISP_ON_AND_CURSOR_OFF						clcd_write(0x0C, INSTRUCTION_COMMAND)
#define EIGHT_BIT_MODE   0x33
void init_clcd(void);
void clcd_print(const unsigned char *data, unsigned char addr);
void clcd_putch(const unsigned char data, unsigned char addr);
void clcd_write(unsigned char bit_values, unsigned char control_bit);


//mkp
void init_matrix_keypad(void);

unsigned char read_matrix_keypad(unsigned char trigger);

unsigned char scan_key(void);

#define LEVEL       1
#define EDGE        0

#define ROW1        RB5
#define ROW2        RB6
#define ROW3        RB7

#define COL1        RB1
#define COL2        RB2
#define COL3        RB3
#define COL4        RB4

#define SW1         1
#define SW2         2
#define SW3         3
#define SW4         4
#define SW5         5
#define SW6         6
#define SW7         7
#define SW8         8
#define SW9         9
#define SW10        10
#define SW11        11
#define SW12        12


#define ALL_RELEASED    0xFF


//adc
void __interrupt() isr(void);
void init_timer0();

void init_adc();
void init_led();
void init_config();

unsigned int read_adc(unsigned char channel);

#define CHANNEL0        0
#define CHANNEL1        1
#define CHANNEL2        2
#define CHANNEL3        3
#define CHANNEL4        4
#define CHANNEL5        5
#define CHANNEL6        6
#define CHANNEL7        7
#define CHANNEL8        8
#define CHANNEL9        9
#define CHANNEL10       10


//i2c
void init_i2c(void);
void i2c_start(void);
void i2c_rep_start(void);
void i2c_stop(void);
void i2c_write(unsigned char data);
unsigned char i2c_read(void);
void display_time(void);
void get_time(void);



//ds1307
#define SLAVE_READ		0xD1
#define SLAVE_WRITE		0xD0

#define SEC_ADDR		0x00
#define MIN_ADDR		0x01
#define HOUR_ADDR		0x02
#define DAY_ADDR		0x03
#define DATE_ADDR		0x04
#define MONTH_ADDR		0x05
#define YEAR_ADDR		0x06
#define CNTL_ADDR		0x07

void init_ds1307(void);
void write_ds1307(unsigned char address1,  unsigned char data);
unsigned char read_ds1307(unsigned char address1);
void save_log(unsigned char speed, unsigned char gear);
void read_log(unsigned char addr);
void view_log(void);


//ext_eeprom
#define SLAVE_READ_E		0xA1
#define SLAVE_WRITE_E		0xA0
#define LOG_INDEX_ADDR      100
#define LOG_COUNT_ADDR      101
#define ADDR_CHECK          102

void write_external_eeprom(unsigned char address1,  unsigned char data);
unsigned char read_external_eeprom(unsigned char address1);


//uart
void init_uart(void);

void putchar(unsigned char ch);

void puts(unsigned char *data);

unsigned char getch(void);


#define CLCD_PORT			PORTD
#define CLCD_EN				RC2
#define CLCD_RS				RC1
#define CLCD_RW				RC0
#define CLCD_BUSY			RD7
#define PORT_DIR			TRISD7


#define HI												1
#define LO												0

#define INPUT											0xFF
#define OUTPUT											0x00

#define DATA_COMMAND									1
#define INSTRUCTION_COMMAND								0
#define _XTAL_FREQ                  20000000
#define LINE1(x)									(0x80 + (x))
#define LINE2(x)										(0xC0 + (x))

#define TWO_LINE_5x8_MATRIX_8_BIT					clcd_write(0x38, INSTRUCTION_COMMAND)
#define CLEAR_DISP_SCREEN				                clcd_write(0x01, INSTRUCTION_COMMAND)
#define CURSOR_HOME							clcd_write(0x02, INSTRUCTION_COMMAND)
#define DISP_ON_AND_CURSOR_OFF						clcd_write(0x0C, INSTRUCTION_COMMAND)
#define EIGHT_BIT_MODE   0x33
void init_clcd(void);
void clcd_print(const unsigned char *data, unsigned char addr);
void clcd_putch(const unsigned char data, unsigned char addr);
void clcd_write(unsigned char bit_values, unsigned char control_bit);

#endif	/* MAIN_H */

