/*
 * File:   main.c
 * Author: Anusha
 * Project - Car Black Box
 *
 * Created on 8 April, 2026, 12:12 PM
 */


#include <xc.h>
#include"main.h"

extern unsigned char log_count;
extern unsigned char log_index;

void init_config(void)
{
	init_clcd();
	init_i2c();
	init_ds1307();
    init_matrix_keypad();
    init_adc();
    init_uart();
}

void main(void)
{
	init_config();
    
    //storing previous data in external eeprom
    if(read_external_eeprom(ADDR_CHECK) == 0XAA)
    {
        log_count = read_external_eeprom(LOG_COUNT_ADDR);
        log_index = read_external_eeprom(LOG_INDEX_ADDR);
    }
    
    write_external_eeprom(ADDR_CHECK,0XAA);
    
    unsigned int speed;
    unsigned char speed_str[6];
    
    char *gear[] = {"N","1","2","3","4","5","R"};
    unsigned char inc = 0;
    

	while (1)
	{
  
        clcd_print("SPD GEA   RTC",LINE1(0));
		
        //collecting and displaying the time 
        get_time();
		display_time();

        //collecting speed data
        speed = (read_adc(CHANNEL4) / 10.23);
        
        
        if(inc == 0)
        {
            speed = 0;
        }
          
        //speed data is converting into string
        int_to_str(speed,speed_str);
        
        //displaying speed data in clcd
        clcd_print(speed_str,LINE2(0));
        
        //reading mkp switch
        unsigned char key = read_matrix_keypad(EDGE);
        
        if(key == SW1)          //Incrementing Switch
        {
            if(inc < 6)
            {
                inc++;
                //saving speed and gear data in external eeprom
                save_log(speed, inc);
            }
        }
        else if(key == SW2)     //Decrementing Switch
        {
            if(inc > 0)
            {
                inc--;
                //saving speed and gear data in external eeprom
                save_log(speed, inc);
            }  
        }
        else if(key == SW11)     //Enter Switch
        {   
            display_menu();
            CLEAR_DISP_SCREEN;
        }
        
        if(key == SW3)
        {
            //collision occurred
            collision();
            save_log(speed, inc);
            CLEAR_DISP_SCREEN;
            inc = 0;
            
        }
    
        //displaying gear data in clcd
        clcd_print(gear[inc],LINE2(5));
       
	}
    
    return;
}
