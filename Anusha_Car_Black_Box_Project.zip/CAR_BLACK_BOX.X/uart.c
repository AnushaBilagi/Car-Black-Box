#include <xc.h>
#include "main.h"

void init_uart(void)
{ 
    TRISC6 = 0;  //TRANSMIT
    TRISC7 = 1;  //RECEIVE
    
    //TXSTA REG
    TXEN = 1;  //TRANSMIT ENABLE
    SYNC = 0;  //ASYNCHRONOUS MODE
    BRGH = 1;  //HIGH BAUD RATE SELECT BIT (HIGH SPEED)
    
    //RCSTA REG
    SPEN = 1;  //SERIAL PORT  ENABLE BIT
    CREN = 1;  //CONTINUOUS RECEIVE BIT
    
    //BAUDCON REG
    ABDEN = 0; //AUTO BAUD RATE BIT DISABLED
    
    WUE = 0; //WAKE UP EBABLE BIT IS DESABLED
    
    BRG16 = 0; //8-BIT BAUD RATE ENABLE BIT
    
    SPBRG = 129;  //9600 BAUD RATE 
       
}

void putchar(unsigned char ch)
{
    while(!TXIF);
    
    TXREG = ch;
}

void puts(unsigned char *data)
{
    while(*data != '\0')
    {
        putchar(*data);
        data++;
    }
}

unsigned char getch(void)
{
    while(!RCIF);  //wait until data receive
    
    return RCREG;    
    
}

