/*
 * File:   adc.c
 * Author: anush
 *
 * Created on 18 March, 2026, 8:39 AM
 */


#include <xc.h>
#include"main.h"


void init_adc()
{
    ADON = 1;  //Turn ON ADC
    
    ADFM = 1;    //Select Right justified
            
    ACQT2 = 0;
    ACQT1 = 1;
    ACQT0 = 0;  //select 4 TAD Acquisition time
    
    ADCS2 = 0;
    ADCS1 = 1;
    ADCS0 = 0;  //Select FOSC/32 - 1.6micro sec*


}

unsigned int read_adc(unsigned char channel)
{
    ADCON0 = (channel << 2) | (ADCON0 & 0xC3);
    
    //start the ADC conversion
    GO = 1;
    
    //wait for conversion to complete
    while(GO);
    
    return (ADRESH << 8) | ADRESL;
}
