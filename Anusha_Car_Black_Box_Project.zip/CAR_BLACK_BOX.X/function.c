#include <xc.h>
#include"main.h"

unsigned char clock_reg[3];
unsigned char calender_reg[4];
unsigned char time[9];
unsigned char date[11];
unsigned char log_count = 0;
unsigned char log_index = 0;   // for storing 10 data only
unsigned char index = 0;
unsigned char hh, mm, ss;


void int_to_str(unsigned int num, char *str)
{
    str[0] = (num / 100) % 10 + '0';
    str[1] = (num / 10) % 10 + '0';
    str[2] = (num % 10) + '0';
    str[3] = '\0';
}


void display_time(void)
{
	clcd_print(time, LINE2(8));
}

void get_time(void)
{
	clock_reg[0] = read_ds1307(HOUR_ADDR);
	clock_reg[1] = read_ds1307(MIN_ADDR);
	clock_reg[2] = read_ds1307(SEC_ADDR);

	if (clock_reg[0] & 0x40)
	{
		time[0] = '0' + ((clock_reg[0] >> 4) & 0x01);
		time[1] = '0' + (clock_reg[0] & 0x0F);
	}
	else
	{
		time[0] = '0' + ((clock_reg[0] >> 4) & 0x03);
		time[1] = '0' + (clock_reg[0] & 0x0F);
	}
	time[2] = ':';
	time[3] = '0' + ((clock_reg[1] >> 4) & 0x0F);
	time[4] = '0' + (clock_reg[1] & 0x0F);
	time[5] = ':';
	time[6] = '0' + ((clock_reg[2] >> 4) & 0x0F);
	time[7] = '0' + (clock_reg[2] & 0x0F);
	time[8] = '\0';
}


void display_menu()
{
    CLEAR_DISP_SCREEN;
    unsigned char arrow = 0;
    unsigned char key;
    char *menu[] = {"View Log","Download Log","Set Time","Clear Log"};
    while(1)
    {
        key = read_matrix_keypad(EDGE);
        
        if(key == SW1)
        {
            if(arrow < 3)
            {
                CLEAR_DISP_SCREEN;
                arrow++;
            }
        }
        else if(key == SW2)
        {
            if(arrow > 0)
            {
                CLEAR_DISP_SCREEN;
                arrow--;
            }
        }
        else if(key == SW11)
        {
            switch(arrow)   
            {
                case 0:  
                    //View Log
                    view_log();   
                    break;

                case 1:   
                    // Download Log
                    download_log();
                    break;

                case 2:   
                    // Set Log
                    set_log();
                    break;

                case 3:   
                    // Clear Log
                    clear_log();
                    break;
            }
        }
        else if(key == SW12)
        {
            break;
        }
        clcd_print("-> ",LINE1(0));
        clcd_print(menu[arrow],LINE1(2));

        if(arrow+1 < 4)
        {
            clcd_print(menu[arrow + 1],LINE2(2));
        }
        else
        {
            clcd_print("             ",LINE2(2));
        }
    }
}

void collision()
{
    CLEAR_DISP_SCREEN;
    clcd_print("Collision", LINE1(1));
    clcd_print("Detected", LINE2(5));
    while(1)
    {
        // read key
        unsigned char key = read_matrix_keypad(EDGE);

        if(key != ALL_RELEASED)
        {
            break;
        }
    }
    CLEAR_DISP_SCREEN;
}



void save_log(unsigned char speed, unsigned char gear)
{
    unsigned char hr, min, sec;

    get_time();  
    
    //converting time BCD into integer value
    hr  = (((clock_reg[0] >> 4) & 0x03) * 10) + (clock_reg[0] & 0x0F);
    min = ((clock_reg[1] >> 4) * 10) + (clock_reg[1] & 0x0F);
    sec = ((clock_reg[2] >> 4) * 10) + (clock_reg[2] & 0x0F);

    unsigned char eeprom_addr = log_index * 5;

    //storing all data in external eeprom
    write_external_eeprom(eeprom_addr++, hr);
    write_external_eeprom(eeprom_addr++, min);
    write_external_eeprom(eeprom_addr++, sec);
    write_external_eeprom(eeprom_addr++, speed);
    write_external_eeprom(eeprom_addr++, gear);
    
    //to allocate only 50 bytes of memory
    if(eeprom_addr == 50)
    {
        eeprom_addr = 0;
    }
    
    log_index++;
    //for storing prev data
    write_external_eeprom(LOG_INDEX_ADDR,log_index);
    
    //to read only 10 data
    if(log_index >= 10)
    {
        log_index = 0;
    }
    
    if(log_count < 10)
    {
        log_count++;
        //for storing prev data
        write_external_eeprom(LOG_COUNT_ADDR,log_count);
    }
        
}

void read_log1(unsigned char addr, unsigned char ind)
{
    unsigned char hr, min, sec, speed, gear;

    //reading all data from external eeprom
    hr    = read_external_eeprom(addr);
    min   = read_external_eeprom(addr + 1);
    sec   = read_external_eeprom(addr + 2);
    speed = read_external_eeprom(addr + 3);
    gear  = read_external_eeprom(addr + 4);

    clcd_print("$ SPD GR TIME",LINE1(0));
    __delay_ms(200);
    
    //printing slno
    if((ind + 1) >= 10)
    {
        clcd_putch('1', LINE2(0));
        clcd_putch('0', LINE2(1));
    }
    else
    {
        clcd_putch((ind + 1) + '0', LINE2(0));
        clcd_putch(' ', LINE2(1));   
    }

    //Displaying Time
    clcd_putch(hr/10 + '0', LINE2(8));
    clcd_putch(hr%10 + '0', LINE2(9));
    clcd_putch(':', LINE2(10));

    clcd_putch(min/10 + '0', LINE2(11));
    clcd_putch(min%10 + '0', LINE2(12));
    clcd_putch(':', LINE2(13));

    clcd_putch(sec/10 + '0', LINE2(14));
    clcd_putch(sec%10 + '0', LINE2(15));

    //Displaying Speed
    clcd_putch(((speed/100) % 10) + '0', LINE2(2));
    clcd_putch(((speed/10) % 10) + '0', LINE2(3));
    clcd_putch(speed%10 + '0', LINE2(4));

    //Displaying Gear
    if(gear <= 5)
    {
        clcd_putch(gear + '0', LINE2(6));
    }
    else 
    {
        clcd_putch('R', LINE2(6));
    }
}

void view_log(void)
{
    unsigned char key;
    unsigned char addr;
    
    CLEAR_DISP_SCREEN;
    
    //No data found
    if(log_count == 0)
    {
        clcd_print("No Logs", LINE1(3));
        __delay_ms(2000);
        return;
    }

    while(1)
    {
        addr = ((log_index + index) % log_count) * 5;
        
        read_log1(addr,index);

        key = read_matrix_keypad(EDGE);

        if(key == SW1)   // next
        {
            CLEAR_DISP_SCREEN;
            index++;
            if(index >= log_count)
                index = 0;
        }
        else if(key == SW2)   // prev
        {
            CLEAR_DISP_SCREEN;
            if(index == 0)
                index = log_count - 1;
            else
                index--;
        }
        else if(key == SW12)   // exit
        {
            CLEAR_DISP_SCREEN;
            break;
            return;
        }
    }
}

void clear_log()
{
    //clearing the data
    log_count = 0;
    write_external_eeprom(101,log_count);
    CLEAR_DISP_SCREEN;
    
    clcd_print("Cleared",LINE1(2));
    clcd_print("Successfully",LINE2(3));
    __delay_ms(2000);
}

void download_log()
{
    CLEAR_DISP_SCREEN;
    
    clcd_print("Download",LINE1(2));
    clcd_print("Successfully",LINE2(3));
    __delay_ms(2000);
    
    CLEAR_DISP_SCREEN;
    
    puts(" SLNO   SPD  GEA   TIME\n\r");
    puts("\n");
    
    unsigned char hr, min, sec, speed, gear;
    unsigned char addr;
    unsigned char *slno[] = {"1 ","2 ","3 ","4 ","5 ","6 ","7 ","8 ","9 ","10"};
    unsigned char sl_no = 0;
    
    //printing data in UART
    for(int i = 0; i < log_count;i++)
    {
        addr = ((log_index + i) % log_count) * 5;
        
        hr    = read_external_eeprom(addr);
        min   = read_external_eeprom(addr + 1);
        sec   = read_external_eeprom(addr + 2);
        speed = read_external_eeprom(addr + 3);
        gear  = read_external_eeprom(addr + 4);
        
        puts("  ");
        puts(slno[sl_no++]);
        puts("    ");

        //speed data
        putchar(((speed/100) % 10) + '0');
        putchar(((speed/10) % 10) + '0');
        putchar(speed%10 + '0');
        puts("   ");

        //gear data
        if(gear <= 5)
        {
            putchar(gear + '0');
        }
        else 
        {
            putchar('R');
        }
        puts("   ");

        //time data
        putchar(hr/10 + '0');
        putchar(hr%10 + '0');
        putchar(':');

        putchar(min/10 + '0');
        putchar(min%10 + '0');
        putchar(':');

        putchar(sec/10 + '0');
        putchar(sec%10 + '0');
        puts("\n\r");
        addr = addr + 5;
    }
        
}

void set_log()
{
       CLEAR_DISP_SCREEN;   
       unsigned char field = 0;
       unsigned char field_change[3] = {2,0,1};
       unsigned char hr, min, sec;
       unsigned char blink = 0;
       unsigned long int  delay = 0;
    
    //Setting actual time
    while(1)
    {        
        unsigned char key = read_matrix_keypad(EDGE);
        
        if(key == SW4)
        {
            //Changing Field
            field = field_change[field];
        }
        
        if(key == SW1)  //Incrementing 
        {
            if(field == 0)
            {
                ss++;
                if(ss == 60)
                {
                    ss = 0;
                } 
            }
            else if(field == 1)
            {
                hh++;
                if(hh == 24)
                {
                    hh = 0;
                }
            }
            else
            {
                mm++;
                if(mm == 60)
                {
                    mm = 0;
                }
            }
        }
        
        if(key == SW2)  //Decrementing
        {
            if(field == 0)
            {
                ss--;
                if(ss == 255)
                {
                    ss = 59;
                }
            }
            else if(field == 1)
            {
                hh--;
                if(hh == 255)
                {
                    hh = 23;
                }
            }
            else
            {
                mm--;
                if(mm == 255)
                {
                    mm = 59;
                }
            }
        }
        if(key == SW11) //setting time
        {
            //converting integer value into BCD format
            hr  = (((hh / 10) << 4)|(hh % 10));
            min = (((mm / 10) << 4)|(mm % 10));
            sec = (((ss / 10) << 4)|(ss % 10));
            
            //storing modified time 
            write_ds1307(HOUR_ADDR,hr);
            write_ds1307(MIN_ADDR,min);
            write_ds1307(SEC_ADDR,sec);
            
            CLEAR_DISP_SCREEN;
            clcd_print("Set Time",LINE1(2));
            clcd_print("Completed",LINE2(3));
            __delay_ms(2000);
            CLEAR_DISP_SCREEN;
            
            break;
        }
        
        //blinking for setting sec, min and hour value
        if(delay++ >= 500)
        {
            blink = !blink;
            delay = 0;
        }
        
        //Displaying modified time
        clcd_print("HH:MM:SS",LINE1(3));
        
        if(blink == 0 && field == 1)
        {         
            clcd_print("  ",LINE2(3));
        }
        else
        {
            clcd_putch(hh/10 + '0',LINE2(3));
            clcd_putch(hh%10 + '0',LINE2(4));
        }
        clcd_putch(':', LINE2(5));
        
        if(blink == 0 && field == 2)
        {            
            clcd_print("  ",LINE2(6));
        }
        else
        {
            clcd_putch(mm/10 + '0', LINE2(6));
            clcd_putch(mm%10 + '0', LINE2(7));
        }
        clcd_putch(':', LINE2(8));
        
        if(blink == 0 && field == 0)
        {            
            clcd_print("  ",LINE2(9));
        }
        else
        {
            clcd_putch(ss/10 + '0', LINE2(9));
            clcd_putch(ss%10 + '0', LINE2(10));
        }       
    }     
}