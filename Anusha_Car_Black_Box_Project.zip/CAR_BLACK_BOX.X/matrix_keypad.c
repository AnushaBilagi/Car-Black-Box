/*
 * File:   matrix_keypad.c
 * Author: anush
 *
 * Created on 12 March, 2026, 8:02 AM
 */


#include <xc.h>
#include"main.h"

void init_matrix_keypad()
{
    TRISB = (TRISB & 0x1F) | 0x1E;
    
    RBPU = 0;  //To enable pull up on PORTB
}

unsigned char scan_key(void)
{
    //Checking 1st Row switches are pressed or not
    ROW1 = 0;
    ROW2 = ROW3 = 1;
    
    if(COL1 == 0)
        return SW1;
    else if(COL2 == 0)
        return SW4;
    else if(COL3 == 0)
        return SW7;
    else if(COL4 == 0)
        return SW10;
    
    //Checking 2st Row switches are pressed or not
    ROW2 = 0;
    ROW1 = ROW3 = 1;
    
    if(COL1 == 0)
        return SW2;
    else if(COL2 == 0)
        return SW5;
    else if(COL3 == 0)
        return SW8;
    else if(COL4 == 0)
        return SW11;
    
    //Checking 3st Row switches are pressed or not
    ROW3 = 0;
    ROW1 = ROW2 = 1;
    
    if(COL1 == 0)
        return SW3;
    else if(COL2 == 0)
        return SW6;
    else if(COL3 == 0)
        return SW9;
    else if(COL4 == 0)
        return SW12;
    
    return ALL_RELEASED;
    
}

unsigned char read_matrix_keypad(unsigned char trigger)
{
    static int once = 1;
    if(trigger == LEVEL)
    {
        return scan_key();
    }
    else if(trigger == EDGE)
    {
        unsigned int key = scan_key();
        if((key != ALL_RELEASED) && (once == 1))
        {
            once = 0;
            return key;
        }
        else if(key == ALL_RELEASED)
        {
            once = 1;
        }
    }
    return ALL_RELEASED;
}
